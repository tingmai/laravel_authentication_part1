<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\login_project\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>